# Final_Project
 pip.exe install pandas
 pip.exe install bs4
 pip.exe install requests
 pip.exe install easygui
 pip.exe install GoogleNews
  
